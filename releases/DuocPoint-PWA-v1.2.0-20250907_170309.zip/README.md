# DuocPoint PWA v1.2.0

## 🎓 Plataforma Integral Duoc UC

PWA (Progressive Web App) independiente de DuocPoint que funciona tanto en local como en producción.

## 📱 Instalación

### En Navegador Web
1. Abrir `index.html` en cualquier navegador moderno
2. Hacer clic en "Instalar App" cuando aparezca el prompt
3. La app se instalará como aplicación nativa

### En Móvil
1. Abrir `index.html` en Chrome/Safari
2. Tocar el menú del navegador
3. Seleccionar "Agregar a pantalla de inicio"
4. La app se instalará como aplicación nativa

## 🚀 Funcionalidades

- ✅ **9 funcionalidades principales** implementadas
- ✅ **Funcionamiento offline** con Service Worker
- ✅ **Instalable** como app nativa
- ✅ **Responsive** para móvil y desktop
- ✅ **Notificaciones push** (cuando hay conexión)
- ✅ **Caché inteligente** para mejor rendimiento

## 📂 Estructura

```
pwa/
├── index.html              # Página principal
├── manifest.json           # Manifest PWA
├── sw.js                   # Service Worker
├── pwa.js                  # Script PWA
├── styles.css              # Estilos principales
├── main.js                 # JavaScript principal
├── icons/                  # Iconos de la app
├── forum/                  # Módulo de foros
├── market/                 # Módulo de mercado
├── portfolio/              # Módulo de portafolio
├── bienestar/              # Módulo de bienestar
├── reportes/               # Módulo de reportes
├── cursos/                 # Módulo de cursos
├── encuestas/              # Módulo de encuestas
├── horarios/               # Módulo de horarios
└── streetview/             # Módulo de recorridos
```

## 🔧 Configuración

### Para Desarrollo Local
- Abrir `index.html` directamente en el navegador
- Usar un servidor local para mejor rendimiento:
  ```bash
  python -m http.server 8000
  # o
  npx serve .
  ```

### Para Producción
- Subir todos los archivos a un servidor web
- Configurar HTTPS (requerido para Service Worker)
- La PWA funcionará automáticamente

## 📱 Compatibilidad

- ✅ Chrome 80+
- ✅ Firefox 72+
- ✅ Safari 13.1+
- ✅ Edge 80+
- ✅ Móviles Android/iOS

## 🎯 URLs Importantes

- **Inicio**: `/index.html`
- **Foros**: `/forum/`
- **Mercado**: `/market/`
- **Portafolio**: `/portfolio/`
- **Bienestar**: `/bienestar/`
- **Reportes**: `/reportes/`
- **Cursos**: `/cursos/`
- **Encuestas**: `/encuestas/`
- **Horarios**: `/horarios/`
- **Recorridos**: `/streetview/`

## 🆘 Soporte

- **Versión**: 1.2.0
- **Fecha**: 07/09/2025
- **Desarrollado por**: Equipo DuocPoint
- **Para DUOC UC**: Comunidad estudiantil

---

**DuocPoint PWA** - Conectando la comunidad estudiantil de DUOC UC 🎓
